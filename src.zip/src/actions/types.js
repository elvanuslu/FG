export const TIKLANAN_FORM = 'tiklanan_form';
export const SETTINGS = 'settings';
export const KART = 'kart';
export const RESIM = 'resim';
